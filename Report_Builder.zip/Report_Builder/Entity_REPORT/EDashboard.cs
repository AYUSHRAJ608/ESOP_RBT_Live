﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity_REPORT
{
    public class EDashboard
    {
        public int ReportID { get; set; }
        public string key { get; set; }

        public string rolename { get; set; }
        public int emp_code { get; set; }


    }
}
